from fastapi import FastAPI
from fastapi.responses import HTMLResponse
import random

app = FastAPI()

@app.get("/", response_class=HTMLResponse)
async def home():
    return """
    <html>
        <head>
            <title>바카라 예측기</title>
            <style>
                body { font-family: Arial; text-align: center; margin-top: 50px; }
                h1 { color: #333; }
                button { padding: 10px 20px; font-size: 18px; margin-top: 20px; }
                #result { margin-top: 30px; font-size: 24px; color: blue; }
            </style>
        </head>
        <body>
            <h1>바카라 AI 예측기</h1>
            <button onclick="predict()">예측하기</button>
            <div id="result"></div>
            <script>
                async function predict() {
                    const response = await fetch('/predict');
                    const data = await response.json();
                    document.getElementById('result').innerText = '예측 결과: ' + data.result;
                }
            </script>
        </body>
    </html>
    """

@app.get("/predict")
async def predict():
    prediction = random.choice(["Player", "Banker", "Tie"])
    return {"result": prediction}